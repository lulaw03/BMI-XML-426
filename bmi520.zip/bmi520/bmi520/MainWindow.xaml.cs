﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bmi520
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
   
        public partial class MainWindow : Window
        {
            public MainWindow()
            {
                InitializeComponent();
                // 自動調整視窗
                this.SizeToContent = SizeToContent.Manual;
            }

            private void HeightSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
            {
                if (IsInitialized)
                {
                    double heightVal = SliderChange(HeightSlider.Value, HeightNum, " cm");

                    // 位置變換
                    PositionChange(heightVal, Height, HeightC);

                    // BMI
                    BMI();
                }
            }

            private void WeightSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
            {
                if (IsInitialized)
                {
                    double weightVal = SliderChange(WeightSlider.Value, WeightNum, " kg");

                    
                    PositionChange(weightVal, Weight, WeightC);

                    
                    BMI();
                }
            }

            // slider變換則數值改變
            double SliderChange(double value, TextBlock block, string unit)
            {
                double Val = Math.Round(value, 1);
                if (Val < 240)
                {
                    block.Text = Val.ToString() + unit;
                    block.Width = block.Text.Length * 10;
                }
                else
                {
                    Val = Math.Round(value, 0);
                    block.Width = 60;
                    block.Text = Val.ToString() + unit;
                }
                return Val;
            }

            // slider變換則數值改變
            void PositionChange(double changeValue, Border displayBorder, Canvas displayCanvas)
            {
                double a = ((changeValue - 50) / 200) * (displayCanvas.ActualWidth - 60);
                Canvas.SetLeft(displayBorder, a);
            }

            // 計算BMI
            void BMI()
            {
                //BMI
                double height = Math.Round(HeightSlider.Value, 1);
                double weight = Math.Round(WeightSlider.Value, 1);
                double bmi;
                bmi = weight / Math.Pow(height / 100, 2);

                // 顯示bmi結果
                string[] part = Math.Round(bmi, 2).ToString().Split('.');
                BMInum.Text = part[0];
                if (part.Length > 1)
                {
                    BMIdecimal.Text = "." + part[1];
                }
                else
                {
                    BMIdecimal.Text = ".00";
                }


               if (bmi < 24)// 瘦
               {
                BMInum.FontWeight = FontWeights.Light;
                BMIdecimal.FontWeight = FontWeights.Light;
                outputs.FontSize = 13;

                    if (bmi < 18.5)
                   {
                     outputs.Foreground = Brushes.DarkBlue;
                     outputs.Text = "你要多吃一點！";
                   }
               
                    else
                   {
                     outputs.Foreground = Brushes.ForestGreen;
                     outputs.Text = "健康不容易，保持下去！";
                   }
                }

               else if (bmi < 35)// 胖
               {
                   outputs.Foreground = Brushes.Red;
                   outputs.FontSize = 16;

                   {
                       if (bmi < 30)
                       {
                           outputs.FontWeight = FontWeights.Bold;
                           outputs.Text = "小心體重會越來越重喔！";
                       }

                       if (bmi < 27)
                       {
                           outputs.FontWeight = FontWeights.Normal;
                           outputs.Text = "多做點運動！";
                       }


                       else
                       {
                           outputs.FontWeight = FontWeights.Bold;
                           outputs.FontSize = 26;
                           outputs.Text = "不要放棄治療";
                       }
                   }
               }
               else // 疾病
               {
                   outputs.Foreground = new SolidColorBrush(Color.FromRgb(230, 58, 58));
                   outputs.FontWeight = FontWeights.Bold;
                   outputs.FontSize = 30;
                   outputs.Text = "你已經胖到會生病的程度了，請檢討";
               } 
            }

        

            // Content size changes as window changes size
            void ChangeWindowSize(object sender, SizeChangedEventArgs e)
            {
                PositionChange(SliderChange(HeightSlider.Value, HeightNum, " cm"), Height, HeightC);
                PositionChange(SliderChange(WeightSlider.Value, WeightNum, " kg"), Weight, WeightC);
            }

            private void decor_Click(object sender, RoutedEventArgs e)//outputs
            {
                HeightSlider.Value = 150;
                WeightSlider.Value = 50;
                BMInum.Text = "22";
                BMIdecimal.Text = ".22";
            }
           
      }
}
    

