﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bmi520
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // 自動調整視窗大小和其物件位置
            this.SizeToContent = SizeToContent.Height;
        }


        private void WeightSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {           
            // 體重的數字顯示體重條的數值
            WeightNum.Text = WeightSlider.Value.ToString("0.0");

            // 體重的數字跟著滑桿
            Canvas.SetLeft(WeightNum, WeightSlider.Value );

            // 為了計算BMI,設變數Height、Weight的值分別為HeightNum及WeightNumr數值
            double Height = double.Parse(HeightNum.Text);
            double Weight = double.Parse(WeightNum.Text);

            // 計算bmi值
            double BMI = Weight /( Math.Pow((Height / 100), 2));

            // 顯示BMI，需對應整數和小數值
            string[] part = Math.Round(BMI, 2).ToString().Split('.');

            string BMInum = part[0];
            string BMIdecimal = part[1];

            if (part.Length > 1)
            {
                BMIdecimal = "." + part[1];
            }
            else
            {
                BMIdecimal = ".00";
            }
        }

        private void HeightSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // 身高的數字對應拉條
            HeightNum.Text = HeightSlider.Value.ToString("0.0");

            // 身高的數字跟著滑桿
            Canvas.SetLeft(HeightNum, HeightSlider.Value * 2);

        }
    }
}
